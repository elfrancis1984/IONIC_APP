


export const firebaseConfig = {
  apiKey: "AIzaSyAECb1XLDRSuG1k5kuRdqO184bNBR4rP4s",
  authDomain: "tracker-8f49f.firebaseapp.com",
  databaseURL: "https://tracker-8f49f.firebaseio.com",
  projectId: "tracker-8f49f",
  storageBucket: "tracker-8f49f.appspot.com",
  messagingSenderId: "145943821416"
};
