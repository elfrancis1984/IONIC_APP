


export { GuardadosPage } from "./guardados/guardados";
export { HomePage } from "./home/home";
export { MapaPage } from "./mapa/mapa";
export { TabsPage } from "./tabs/tabs";
