

export const firebaseConfig = {
  apiKey: "AIzaSyAhi-VcrfwdfXNlTkAzRuUXNeYRKVtlWps",
  authDomain: "gag-39148.firebaseapp.com",
  databaseURL: "https://gag-39148.firebaseio.com",
  projectId: "gag-39148",
  storageBucket: "gag-39148.appspot.com",
  messagingSenderId: "235124017305"
};
