import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Pagina3Page } from './pagina3';

@NgModule({
  declarations: [
    Pagina3Page
  ],
  imports: [
    IonicPageModule.forChild(Pagina3Page),
  ],
  exports: [
    Pagina3Page
  ]
})
export class Pagina3Module {}
